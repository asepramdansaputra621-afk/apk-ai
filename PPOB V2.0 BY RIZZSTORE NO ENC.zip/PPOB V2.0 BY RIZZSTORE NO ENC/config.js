module.exports = {
    botName: "ISI NAMA BOT LU",
    ownerName: "ISI NAMA OWNER",
    ownerNumber: "62xxx", // Ganti nomor lu (tanpa tanda + & pake 62 jangan 0)
    botNumber: "62xxx",   // Ganti nomor bot lu (buat auto pairing code)
    prefix: "#",
    
    // API OkeConnect (Tarikan Harga)
    apiOkeConnect: "https://okeconnect.com/harga/json?id=905ccd028329b0a", // GA USAH DI UBAH
    
    // API Komputerz (Mutasi QRIS)
    komputerzApiKey: "KAPI-XXXX",  // ambil apikey di https://api.komputerz.site/ login dulu, dpt req 100/days ,kalo mau beli premium nya, bisa ke owner nya
    komputerzUsername: "USERNAME ORKUT LU", // sebenarnya gaguna sih, tapi isi aja, biar ga error
    komputerzToken: "TOKEN ORKUT", // (BACA panduan.txt atau readme.me)
    
        // --- KREDENSIAL OKECONNECT (Untuk Saldo H2H & Transaksi) ---
  okMember: 'ISI OK ID'  // OKXXXXXX
  okPin: 'ISI PIN', // ISI PIN ORDERKUOTA LU
  okPassword: 'ISI PASSWORD', // ISI PASSWORD ORDERKUOTA LU

    
    // Konfigurasi Sistem Pembayaran
    timerQRIS: 600000 // 10 Menit (dalam format milisecond) sebelum QRIS Expired (bebas edit)
}
