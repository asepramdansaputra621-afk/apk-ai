const config = require('./config');
const { getProduk } = require('./lib/fetcher');
const { toRupiah, generateUniq, generateTrxId, getDb, saveDb } = require('./lib/helper');
const { buatStruk } = require('./lib/receipt');
const moment = require('moment-timezone');
const { exec } = require('child_process');
const axios = require('axios');
const fs = require('fs');

// PENAMPUNGAN SEMENTARA BUAT FITUR CANCEL QRIS
const pendingQRIS = {}; 

module.exports = async (sock, m) => {
    try {
        const body = (m.message?.conversation || m.message?.extendedTextMessage?.text || '').trim();
        if (!body) return;

        const noPrefixCmd = [
            'dana', 'gopay', 'ovo', 'grab', 'linkaja', 'shopeepay', 
            'ml', 'ff', 'pubg', 'hok', 'aov', 'pointblank', 'cod', 'valorant', 'genshin',
            'ptelkomsel', 'pindosat', 'paxis', 'psmartfren', 'ptri', 'pxl', 'pbyu',
            'dtelkomsel', 'dindosat', 'daxis', 'dsmartfren', 'dtri', 'dxl', 'dbyu', 'pln', 'cekuser', 'ceksaldo', 'cekip', 'admin', 'panel', 'belisc', 'beliscript', 'cancel'
        ];
        
        let isCmd = body.startsWith(config.prefix);
        let command = '';
        let args = [];

        if (isCmd) {
            args = body.slice(config.prefix.length).trim().split(/ +/);
            command = args.shift().toLowerCase();
        } else if (noPrefixCmd.includes(body.toLowerCase())) {
            isCmd = true;
            command = body.toLowerCase();
            args = [];
        }

        if (!isCmd) return;

        const sender = m.key.remoteJid;
        const pushname = m.pushName || "Bosku";
        const isOwner = sender.includes(config.ownerNumber);
        const reply = (text) => sock.sendMessage(sender, { text: text }, { quoted: m });

        let db = getDb();
        if (!db.users[sender]) {
            db.users[sender] = { role: 'Member', saldo: 0 };
            saveDb(db);
        }

        const tampilkanProduk = async (kategoriApi, produkApi, judul) => {
            reply(`⏳ Sedang menarik data ${judul} dari server pusat...`);
            let list = await getProduk();
            let listproduk = list.filter(i => i.kategori == kategoriApi && (produkApi ? i.produk == produkApi : true));
            if (listproduk.length === 0) return reply(`❌ Maaf, produk ${judul} sedang tidak tersedia.`);
            listproduk.sort((a, b) => Number(a.harga) - Number(b.harga));
            let teks = `╔════════════════════╗\n║ 🔥 *${judul}* 🔥 ║\n╚════════════════════╝\n\n*Cara Beli:* ${config.prefix}order [Kode] [Tujuan]\n*Status:* ✅ Ready | ❌ Kosong\n──────────────────\n\n`;
            listproduk.map(i => {
                let hargaFix = isOwner ? Number(i.harga) : Number(i.harga) + Number(db.settings.profitPPOB);
                teks += `🏷️ *${i.keterangan}*\n ├ 💳 Harga: Rp${toRupiah(hargaFix)}\n ├ 🔑 Kode : *${i.kode}*\n └ 📊 Status: ${i.status == 1 ? "✅ Ready" : "❌ Kosong"}\n\n`;
            });
            reply(teks);
        };

        switch (command) {
            case 'menu':
            case 'help': {
                let teks = `╔══════════════════════╗\n║ 🛒 *WARUNG RIZZSTORE* 🛒 ║\n╚══════════════════════╝\n\nHalo Kak *${pushname}*! 👋\n\n*📊 INFO USER*\n⊶ Tag  : @${sender.split("@")[0]}\n⊶ Saldo: Rp ${toRupiah(db.users[sender].saldo)}\n\n╭───╼「 *KATEGORI* 」\n│ ✦ ${config.prefix}listgame\n│ ✦ ${config.prefix}listemoney\n│ ✦ ${config.prefix}listpulsa\n│ ✦ ${config.prefix}listdata\n│ ✦ ${config.prefix}pln\n╰───────────────╼\n\n╭───╼「 *ORDER* 」\n│ ✦ ${config.prefix}order [kode] [tuju] (Saldo)\n│ ✦ ${config.prefix}order2 [kode] [tuju] (QRIS)\n│ ✦ ${config.prefix}cancel [ID_Trx]\n╰───────────────╼\n\n╭───╼「 *SCRIPT* 」\n│ ✦ ${config.prefix}beliscript\n╰───────────────╼`;
                reply(teks);
            }
            break;

            case 'cancel': {
                if (args.length < 1) return reply(`❌ Format salah!\nContoh: *${config.prefix}cancel TRX-1234*`);
                let idCancel = args[0].toUpperCase();
                if (pendingQRIS[idCancel] && pendingQRIS[idCancel].status === 'PENDING') {
                    if (pendingQRIS[idCancel].sender !== sender && !isOwner) return reply('❌ Kamu tidak memiliki akses.');
                    pendingQRIS[idCancel].status = 'CANCELLED';
                    await sock.sendMessage(sender, { delete: pendingQRIS[idCancel].msgKey });
                    reply(`✅ Pesanan *${idCancel}* berhasil dibatalkan.`);
                } else { reply(`❌ Transaksi tidak ditemukan atau sudah selesai.`); }
            }
            break;

            // --- ORDER VIA QRIS DINAMIS ---
            case 'order2': {
                if (args.length < 2) return reply(`❌ Format salah!`);
                let kodeProduk = args[0].toUpperCase();
                let tujuan = args[1];
                let list = await getProduk();
                let produk = list.find(i => i.kode === kodeProduk);
                if (!produk || produk.status != 1) return reply('❌ Produk kosong.');
                
                let nominalMurni = isOwner ? Number(produk.harga) : Number(produk.harga) + Number(db.settings.profitPPOB);
                let totalBayar = nominalMurni + generateUniq();
                let idTrx = generateTrxId();

                try {
                    const { data } = await axios.get("https://api.komputerz.site/api/v1/orderkuota/createpayment", {
                        params: {
                            apikey: config.komputerzApiKey.trim(),
                            username: config.komputerzUsername.trim(),
                            token: config.komputerzToken.trim(),
                            amount: totalBayar.toString()
                        },
                        timeout: 30000
                    });
                    
                    if (data.status === true) {
                        // AMBIL GAMBAR CAKEP LANGSUNG DARI KOMPUTERZ
                        let urlQrisDinamis = data.result?.qris_image || data.qris_image;
                        
                        // Fallback pake QuickChart kalau API ga ngasih link gambar
                        if (!urlQrisDinamis) {
                            let qrData = data.result?.qris_raw || data.qris_raw;
                            urlQrisDinamis = `https://quickchart.io/qr?text=${encodeURIComponent(qrData)}&size=500&margin=2`;
                        }

                        let msgQris = await sock.sendMessage(sender, { image: { url: urlQrisDinamis }, caption: `🧾 *INVOICE QRIS DINAMIS*\n\n⊶ ID Trx: *${idTrx}*\nProduk: ${produk.keterangan}\nTotal: *Rp ${toRupiah(totalBayar)}*\n\n_Ketik *${config.prefix}cancel ${idTrx}* jika ingin batal._` });

                        pendingQRIS[idTrx] = { status: 'PENDING', msgKey: msgQris.key, sender: sender };

                        let time = Date.now() + 600000;
                        while (pendingQRIS[idTrx] && pendingQRIS[idTrx].status === 'PENDING') {
                            await new Promise(resolve => setTimeout(resolve, 10000));
                            if (!pendingQRIS[idTrx] || pendingQRIS[idTrx].status === 'CANCELLED') return;
                            if (Date.now() >= time) { 
                                pendingQRIS[idTrx].status = 'EXPIRED'; 
                                await sock.sendMessage(sender, { delete: msgQris.key }); 
                                return reply(`❌ Waktu habis.`); 
                            }
                            try {
                                const { data: mutasiData } = await axios.get("https://api.komputerz.site/api/v1/orderkuota/mutasiqr", {
                                    params: { apikey: config.komputerzApiKey.trim(), username: config.komputerzUsername.trim(), token: config.komputerzToken.trim() }, timeout: 30000
                                });

                                if (JSON.stringify(mutasiData).includes(totalBayar.toString())) {
                                    pendingQRIS[idTrx].status = 'PAID'; await sock.sendMessage(sender, { delete: msgQris.key });
                                    reply(`✅ Bayar Rp ${toRupiah(totalBayar)} Sukses! Memproses produk...`);
                                    
                                    const resH2h = await axios.get(`https://b2b.okeconnect.com/trx-v2`, { params: { product: produk.kode, dest: tujuan, refID: idTrx, memberID: config.okMember, pin: config.okPin, password: config.okPassword } });
                                    let statusQR = resH2h.data.status;
                                    if (statusQR === "GAGAL") return reply(`❌ Gagal pusat: ${resH2h.data.message}`);
                                    
                                    let attemptQR = 0;
                                    while (statusQR !== "SUKSES" && statusQR !== "GAGAL" && attemptQR < 36) {
                                        await new Promise(resolve => setTimeout(resolve, 5000)); attemptQR++;
                                        let checkResQR = await axios.get(`https://b2b.okeconnect.com/trx-v2`, { params: { product: produk.kode, dest: tujuan, refID: idTrx, memberID: config.okMember, pin: config.okPin, password: config.okPassword } });
                                        statusQR = checkResQR.data.status;
                                        if (statusQR === "SUKSES") {
                                            let pathStruk = await buatStruk({ status: "BERHASIL", tanggal: moment.tz("Asia/Jakarta").format("DD/MM/YYYY | HH:mm"), produk: produk.keterangan, tujuan: tujuan, trxId: idTrx, total: toRupiah(totalBayar), sn: checkResQR.data.sn });
                                            await sock.sendMessage(sender, { image: { url: pathStruk }, caption: `✅ Pesanan Sukses!` }); break;
                                        }
                                    }
                                }
                            } catch (e) {}
                        }
                        delete pendingQRIS[idTrx];
                    } else { reply(`❌ Gagal generate QRIS: ${JSON.stringify(data)}`); }
                } catch (err) { 
                    let infoMsg = err.response?.data?.message || err.response?.data || err.message;
                    reply(`❌ Gagal QRIS.\nInfo: ${JSON.stringify(infoMsg)}`); 
                }
            }
            break;

            // --- JUALAN SCRIPT OTOMATIS (BELISC) ---
            case 'belisc':
            case 'beliscript': {
                let hargaScript = 150000; 
                let totalBayar = hargaScript + generateUniq();
                let idTrx = "SC-" + generateTrxId();
                reply('⏳ Menyiapkan QRIS Pembelian Script...');
                try {
                    const { data } = await axios.get("https://api.komputerz.site/api/v1/orderkuota/createpayment", {
                        params: { apikey: config.komputerzApiKey.trim(), username: config.komputerzUsername.trim(), token: config.komputerzToken.trim(), amount: totalBayar.toString() }, timeout: 30000
                    });

                    if (data.status === true) {
                        // AMBIL GAMBAR CAKEP LANGSUNG DARI KOMPUTERZ
                        let urlQrisDinamis = data.result?.qris_image || data.qris_image;
                        
                        if (!urlQrisDinamis) {
                            let qrData = data.result?.qris_raw || data.qris_raw;
                            urlQrisDinamis = `https://quickchart.io/qr?text=${encodeURIComponent(qrData)}&size=500&margin=2`;
                        }

                        let msgQris = await sock.sendMessage(sender, { image: { url: urlQrisDinamis }, caption: `🧾 *INVOICE SCRIPT*\n\nID: *${idTrx}*\nTotal: *Rp ${toRupiah(totalBayar)}*\n\n_Batal? Ketik *${config.prefix}cancel ${idTrx}*_` });
                        pendingQRIS[idTrx] = { status: 'PENDING', msgKey: msgQris.key, sender: sender };
                        
                        let time = Date.now() + 600000;
                        while (pendingQRIS[idTrx] && pendingQRIS[idTrx].status === 'PENDING') {
                            await new Promise(resolve => setTimeout(resolve, 10000));
                            if (!pendingQRIS[idTrx] || pendingQRIS[idTrx].status === 'CANCELLED') return;
                            if (Date.now() >= time) { pendingQRIS[idTrx].status = 'EXPIRED'; await sock.sendMessage(sender, { delete: msgQris.key }); return reply('❌ Waktu habis.'); }
                            try {
                                const { data: mutasiData } = await axios.get("https://api.komputerz.site/api/v1/orderkuota/mutasiqr", {
                                    params: { apikey: config.komputerzApiKey.trim(), username: config.komputerzUsername.trim(), token: config.komputerzToken.trim() }, timeout: 30000
                                });

                                if (JSON.stringify(mutasiData).includes(totalBayar.toString())) {
                                    pendingQRIS[idTrx].status = 'PAID'; await sock.sendMessage(sender, { delete: msgQris.key });
                                    reply(`✅ Pembayaran *Rp ${toRupiah(totalBayar)}* Diterima!\n⏳ Sedang meracik file Script Bot...`);
                                    const templateConfig = `module.exports = {\n    botName: "ISI NAMA BOT LU",\n    ownerName: "ISI NAMA OWNER",\n    ownerNumber: "62xxx",\n    botNumber: "62xxx",\n    prefix: "#",\n    apiOkeConnect: "https://okeconnect.com/harga/json?id=905ccd028329b0a",\n    komputerzApiKey: "KAPI-XXXX",\n    komputerzUsername: "USERNAME ORKUT LU",\n    komputerzToken: "TOKEN ORKUT",\n    okMember: 'ISI OK ID',\n    okPin: 'ISI PIN',\n    okPassword: 'ISI PASSWORD',\n    timerQRIS: 600000\n};`;
                                    if (!fs.existsSync('./temp_mentah')) fs.mkdirSync('./temp_mentah');
                                    exec(`cp -r . temp_mentah/ && rm -rf temp_mentah/node_modules temp_mentah/session temp_mentah/config.js temp_mentah/*.zip temp_mentah/temp_mentah`, (err) => {
                                        fs.writeFileSync('./temp_mentah/config.js', templateConfig);
                                        exec(`cd temp_mentah && zip -r ../SC_WarungRizzStore_V40.zip .`, async (err2) => {
                                            await sock.sendMessage(sender, { document: { url: './SC_WarungRizzStore_V40.zip' }, mimetype: 'application/zip', fileName: `Script_WarungRizzStore_V40.zip`, caption: `🎉 Script V40 Siap Digunakan!` }, { quoted: m });
                                            exec('rm -rf temp_mentah SC_WarungRizzStore_V40.zip');
                                        });
                                    });
                                }
                            } catch (e) {}
                        }
                        delete pendingQRIS[idTrx];
                    } else { reply(`❌ Gagal QRIS.`); }
                } catch (err) { reply(`❌ Gagal QRIS Script.`); }
            }
            break;
            
            // --- ORDER VIA SALDO ---
            case 'order': {
                if (args.length < 2) return reply(`❌ Format: *${config.prefix}order kode tujuan*`);
                let kodeProduk = args[0].toUpperCase();
                let tujuan = args[1];
                let list = await getProduk();
                let produk = list.find(i => i.kode === kodeProduk);
                if (!produk || produk.status != 1) return reply('❌ Produk tidak tersedia.');
                let hargaFix = isOwner ? Number(produk.harga) : Number(produk.harga) + Number(db.settings.profitPPOB);
                if (db.users[sender].saldo < hargaFix) return reply(`❌ Saldo kurang! Tagihan: Rp ${toRupiah(hargaFix)}`);
                
                db.users[sender].saldo -= hargaFix; saveDb(db); let idTrx = generateTrxId();
                reply(`✅ Saldo terpotong. ⏳ Memproses pesanan...`);

                try {
                    const res = await axios.get(`https://b2b.okeconnect.com/trx-v2`, { params: { product: produk.kode, dest: tujuan, refID: idTrx, memberID: config.okMember, pin: config.okPin, password: config.okPassword }, timeout: 60000 });
                    let status = res.data.status;
                    if (status === "GAGAL") { db.users[sender].saldo += hargaFix; saveDb(db); reply(`❌ Gagal: ${res.data.message}. Saldo di-refund.`); } 
                    else {
                        reply(`Pesanan diproses pusat, mohon tunggu struk... 🚀`);
                        let attempt = 0;
                        while (status !== "SUKSES" && status !== "GAGAL" && attempt < 36) {
                            await new Promise(r => setTimeout(r, 5000)); attempt++;
                            let checkRes = await axios.get(`https://b2b.okeconnect.com/trx-v2`, { params: { product: produk.kode, dest: tujuan, refID: idTrx, memberID: config.okMember, pin: config.okPin, password: config.okPassword } });
                            status = checkRes.data.status;
                            if (status === "SUKSES") {
                                let pathStruk = await buatStruk({ status: "BERHASIL", tanggal: moment.tz("Asia/Jakarta").format("DD/MM/YYYY | HH:mm"), produk: produk.keterangan, tujuan: tujuan, trxId: idTrx, total: toRupiah(hargaFix), sn: checkRes.data.sn || "SN-TelahDiproses" });
                                await sock.sendMessage(sender, { image: { url: pathStruk }, caption: `✅ Sukses! Sisa saldo: *Rp ${toRupiah(db.users[sender].saldo)}*` }, { quoted: m }); break;
                            }
                        }
                    }
                } catch (err) { db.users[sender].saldo += hargaFix; saveDb(db); reply(`❌ Error H2H.`); }
            }
            break;

            // --- ADMIN DLL ---
            case 'admin':
            case 'panel': {
                if (!isOwner) return reply('❌ Fitur khusus Owner!');
                reply(`╔══════════════════════╗\n║ 👑 *PANEL OWNER* 👑 ║\n╚══════════════════════╝\n\n⚙️ *PENGATURAN*\n✦ ${config.prefix}setprofit [nominal]\n✦ ${config.prefix}anticall [on/off]\n✦ ${config.prefix}backup - Backup Full Server\n\n💰 *SALDO & MEMBER*\n✦ ${config.prefix}addsaldo [nomer] [nominal]\n✦ ${config.prefix}cekuser [nomer]\n\n🔌 *SISTEM H2H*\n✦ ${config.prefix}cekip\n✦ ${config.prefix}ceksaldo`);
            }
            break;
            case 'ceksaldo': {
                if (!isOwner) return reply('❌ Khusus Owner!');
                try {
                    const res = await axios.get(`https://b2b.okeconnect.com/trx-v2/balance`, { params: { memberID: config.okMember, pin: config.okPin, password: config.okPassword } });
                    let saldo = res.data.message ? res.data.message.replace(/[^0-9]/g, '') : 0;
                    reply(`🏦 *SALDO PUSAT*\n\nSisa: *Rp ${toRupiah(saldo)}*`);
                } catch (err) { reply('❌ Gagal.'); }
            }
            break;
            case 'cekip': {
                if (!isOwner) return reply('❌ Khusus Owner!');
                const res = await axios.get('https://api.ipify.org?format=json');
                reply(`🌐 *IP SERVER*\n\nIP: *${res.data.ip}*`);
            }
            break;
            case 'cekuser': {
                if (args.length === 0) { reply(`💳 Saldo kamu saat ini: *Rp ${toRupiah(db.users[sender].saldo)}*`); } 
                else {
                    if (!isOwner) return reply('❌ Khusus Owner!');
                    let target = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
                    if (!db.users[target]) return reply('❌ User tidak ditemukan.');
                    reply(`💳 Saldo user ${args[0]}: *Rp ${toRupiah(db.users[target].saldo)}*`);
                }
            }
            break;
            case 'setprofit': {
                if (!isOwner) return reply('❌ Fitur khusus Owner!');
                if (!args[0]) return reply(`Contoh penggunaan:\n${config.prefix}setprofit 1500`);
                let newProfit = parseInt(args[0]);
                if (isNaN(newProfit)) return reply('❌ Profit harus berupa angka!');
                db.settings.profitPPOB = newProfit; saveDb(db);
                reply(`✅ Keuntungan disetting sebesar: *Rp${toRupiah(newProfit)}* / transaksi.`);
            }
            break;
            case 'addsaldo': {
                if (!isOwner) return reply('❌ Fitur khusus Owner!');
                if (args.length < 2) return reply(`Contoh: ${config.prefix}addsaldo 6285718250588 50000`);
                let target = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
                let nominal = parseInt(args[1]);
                if (isNaN(nominal)) return reply('❌ Nominal harus angka!');
                if (!db.users[target]) db.users[target] = { role: 'Member', saldo: 0 };
                db.users[target].saldo += nominal; saveDb(db);
                reply(`✅ Sukses menambahkan saldo Rp ${toRupiah(nominal)} ke nomor ${args[0]}.\nTotal saldo sekarang: *Rp ${toRupiah(db.users[target].saldo)}*`);
            }
            break;
            case 'backup': {
                if (!isOwner) return reply('❌ Fitur khusus Owner!');
                reply('⏳ Sedang memproses backup seluruh file...');
                exec(`zip -r backup_rizzstore.zip . -x "node_modules/*" "*.zip"`, async (err) => {
                    if (err) return reply('❌ Gagal backup.');
                    await sock.sendMessage(sender, { document: { url: './backup_rizzstore.zip' }, mimetype: 'application/zip', fileName: `Backup_Full.zip` }, { quoted: m });
                    exec('rm backup_rizzstore.zip');
                });
            }
            break;
            
            case 'anticall': {
                if (!isOwner) return reply('❌ Fitur ini khusus Owner!');
                if (!args[0]) return reply(`Contoh: ${config.prefix + command} on / off`);
                if (args[0].toLowerCase() == "on") {
                    db.settings.anticall = true; saveDb(db); reply('✅ Anticall diaktifkan.');
                } else if (args[0].toLowerCase() == "off") {
                    db.settings.anticall = false; saveDb(db); reply('✅ Anticall dinonaktifkan.');
                }
            }
            break;

            case 'dana': await tampilkanProduk("DOMPET DIGITAL", "Top Up Saldo DANA", "SALDO DANA"); break;
            case 'gopay': await tampilkanProduk("DOMPET DIGITAL", "Top Up Saldo Gopay Promo", "SALDO GOPAY"); break;
            case 'ovo': await tampilkanProduk("DOMPET DIGITAL", "Top Up Saldo OVO", "SALDO OVO"); break;
            case 'shopeepay': await tampilkanProduk("DOMPET DIGITAL", "Top Up Saldo Shopee", "SALDO SHOPEEPAY"); break;
            case 'grab': await tampilkanProduk("DOMPET DIGITAL", "Top Up Saldo GRAB Customer", "SALDO GRAB"); break;
            case 'linkaja': await tampilkanProduk("DOMPET DIGITAL", "Top Up Saldo LinkAja", "SALDO LINKAJA"); break;
            case 'ml': await tampilkanProduk("DIGITAL", "TPG Diamond Mobile Legends", "MOBILE LEGENDS"); break;
            case 'ff': await tampilkanProduk("DIGITAL", "TPG Diamond Free Fire", "FREE FIRE"); break;
            case 'pubg': await tampilkanProduk("DIGITAL", "TPG Game Mobile PUBG", "PUBG MOBILE"); break;
            case 'hok': await tampilkanProduk("DIGITAL", "Honor of Kings", "HONOR OF KINGS"); break;
            case 'valorant': await tampilkanProduk("DIGITAL", "Valorant", "VALORANT"); break;
            case 'genshin': await tampilkanProduk("DIGITAL", "Genshin Impact", "GENSHIN IMPACT"); break;
            case 'pln': await tampilkanProduk("TOKEN PLN", "H2H Token PLN Promo", "TOKEN PLN"); break;
            case 'ptelkomsel': await tampilkanProduk("PULSA", "Telkomsel", "PULSA TELKOMSEL"); break;
            case 'pindosat': await tampilkanProduk("PULSA", "Indosat", "PULSA INDOSAT"); break;
            case 'paxis': await tampilkanProduk("PULSA", "Axis", "PULSA AXIS"); break;
            case 'psmartfren': await tampilkanProduk("PULSA", "Smartfren", "PULSA SMARTFREN"); break;
            case 'ptri': await tampilkanProduk("PULSA", "Three", "PULSA TRI"); break;
            case 'pxl': await tampilkanProduk("PULSA", "XL", "PULSA XL"); break;
            case 'pbyu': await tampilkanProduk("PULSA", "By U", "PULSA BY.U"); break;
            case 'dtelkomsel': await tampilkanProduk("DATA", "Telkomsel Data", "DATA TELKOMSEL"); break;
            case 'dindosat': await tampilkanProduk("DATA", "Indosat Data", "DATA INDOSAT"); break;
            case 'daxis': await tampilkanProduk("DATA", "Axis Data", "DATA AXIS"); break;
            case 'dsmartfren': await tampilkanProduk("DATA", "Smartfren Data", "DATA SMARTFREN"); break;
            case 'dtri': await tampilkanProduk("DATA", "Three Data", "DATA TRI"); break;
            case 'dxl': await tampilkanProduk("DATA", "XL Data", "DATA XL"); break;
            case 'dbyu': await tampilkanProduk("DATA", "By U Data", "DATA BY.U"); break;
        }
    } catch (err) { console.error(err); }
};
