// --- KODE SAKTI MAKSA INSTALL (HAPUS KALAU BOT UDAH NYALA) ---
require('child_process').execSync('npm install canvas', {stdio: 'inherit'});

const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const pino = require('pino');
const readline = require("readline");
const config = require('./config');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('session');
    const { version, isLatest } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        logger: pino({ level: 'silent' }), // Silent biar console lu tetep bersih & rapi
        printQRInTerminal: false, // Kita pake Pairing Code
        auth: state,
        browser: ['Ubuntu', 'Chrome', '20.0.04']
    });

    // ==========================================
    // SISTEM PAIRING CODE
    // ==========================================
    if (!sock.authState.creds.registered) {
        console.log(`\nSilakan masukkan nomor WhatsApp bot Anda (Awali dengan 62, contoh: 628xxxx):`);
        const phoneNumber = await question('> ');
        const code = await sock.requestPairingCode(phoneNumber.trim());
        console.log(`\n======================================`);
        console.log(`Tautkan WhatsApp Anda dengan kode ini:`);
        console.log(`[ ${code} ]`);
        console.log(`======================================\n`);
    }

    sock.ev.on('creds.update', saveCreds);

    // ==========================================
    // PANTAU KONEKSI (ANTI PUTUS)
    // ==========================================
    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        
        if (connection === 'close') {
            let reason = lastDisconnect.error?.output?.statusCode;
            if (reason === DisconnectReason.badSession) {
                console.log('❌ Session korup, silakan hapus folder session dan restart bot.');
                process.exit();
            } else if (reason === DisconnectReason.connectionClosed) {
                console.log('Koneksi terputus, menyambungkan ulang...');
                startBot();
            } else if (reason === DisconnectReason.loggedOut) {
                console.log('❌ Perangkat dikeluarkan, silakan hapus folder session dan tautkan ulang.');
                process.exit();
            } else if (reason === DisconnectReason.restartRequired) {
                console.log('Restart diperlukan, merestart...');
                startBot();
            } else {
                console.log(`Koneksi putus. Alasan: ${reason}. Menyambungkan ulang...`);
                startBot();
            }
        } else if (connection === 'open') {
            console.log('\n✨ WARUNG RIZZSTORE V40 BERHASIL TERHUBUNG! ✨\n');
        }
    });

    // ==========================================
    // PINTU MASUK PESAN (CCTV TERPASANG)
    // ==========================================
    sock.ev.on('messages.upsert', async (chatUpdate) => {
        try {
            const m = chatUpdate.messages[0];
            if (!m.message) return;
            
            // Jangan respon status WA
            if (m.key.remoteJid === 'status@broadcast') return;

            // 📸 CCTV BERJALAN DI CONSOLE PTERODACTYL
            console.log('\n=============================');
            console.log('📥 ADA PESAN MASUK DARI:', m.key.remoteJid);
            console.log('📝 ISI PESAN / TIPE:', m.message?.conversation || m.message?.extendedTextMessage?.text || Object.keys(m.message)[0]);
            console.log('=============================\n');

            // Hapus cache biar kalau lu ngedit message.js, nggak perlu restart panel lagi
            delete require.cache[require.resolve('./message')];
            
            // Oper pesannya ke otak utama (message.js)
            require('./message')(sock, m); 

        } catch (err) {
            console.log('❌ Error di pintu masuk index.js:', err);
        }
    });
}

startBot();
